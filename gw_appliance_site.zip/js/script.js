
// Example JS placeholder
console.log('GW Appliance & HVAC site loaded');
